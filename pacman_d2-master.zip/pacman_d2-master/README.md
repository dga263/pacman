# pacman_d2

This was the final project of my Intro to CS class in Fall 2018. The python3 file can be accessed here as well as the images (in a zip file). Enjoy!
